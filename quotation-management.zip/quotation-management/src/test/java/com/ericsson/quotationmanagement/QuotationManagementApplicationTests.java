package com.ericsson.quotationmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuotationManagementApplicationTests {

    @Test
    void contextLoads() {
    }

}
